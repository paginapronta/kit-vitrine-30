# Calendário de 30 dias

Comece em qualquer data. Dia 1 é o primeiro dia da sua sequência, não uma data fixa. Ajuste a frequência à sua rotina e repita a consulta ao estoque antes de cada publicação. Os seis Reels são opcionais e podem substituir o post sugerido naquele dia, deixando a arte para outra data.

| Dia | Arte de feed | Preparação | Reel opcional |
| --- | --- | --- | --- |
| 01 | Uma peça para conhecer de perto | Fotografe uma peça disponível, inteira, em cabide ou manequim, diante de fundo liso. | — |
| 02 | A mesma peça, outro jeito de usar | Fotografe a mesma peça em duas combinações lado a lado, na mesma imagem. Use apenas produtos da loja. | 1 |
| 03 | O que conferir na sua próxima peça | Personalizar os campos e revisar o texto. | — |
| 04 | Chegue mais perto do acabamento | Faça um close nítido da costura, do botão, do bolso ou de outro detalhe real. Evite filtro que altere a cor. | — |
| 05 | O que você mais usa na semana? | Personalizar os campos e revisar o texto. | — |
| 06 | Duas cores para experimentar juntas | Coloque duas peças das cores escolhidas sobre um fundo neutro, com luz uniforme. | 3 |
| 07 | Quer ver uma peça com mais detalhes? | Personalizar os campos e revisar o texto. | — |
| 08 | Um look para [OCASIÃO] | Monte um look completo em cabide, manequim ou superfície limpa. Não inclua acessórios indisponíveis sem explicar na legenda. | — |
| 09 | Como pedir ajuda com o tamanho | Personalizar os campos e revisar o texto. | — |
| 10 | O tecido visto de perto | Fotografe a textura em luz natural e confira a composição na etiqueta. Não faça promessa de conforto ou durabilidade sem base. | 2 |
| 11 | Qual detalhe chama sua atenção? | Personalizar os campos e revisar o texto. | — |
| 12 | Uma base para dois looks | Registre duas combinações reais da mesma peça em uma única imagem. Mantenha distância e luz semelhantes. | — |
| 13 | A etiqueta acompanha a peça | Personalizar os campos e revisar o texto. | — |
| 14 | Um pedacinho da [NOME DA LOJA] | Fotografe a arara, prateleira ou bancada real. Para loja online, monte uma seleção sobre uma mesa, sem simular loja física. | — |
| 15 | Na vitrine por [PREÇO] | Preencher preço, condições e tamanhos. | — |
| 16 | A peça de frente e de costas | Monte uma única imagem com duas fotos da mesma peça, frente e costas. Use a mesma escala e iluminação. | 4 |
| 17 | Qual cor você quer ver por aqui? | Personalizar os campos e revisar o texto. | — |
| 18 | Uma estampa com uma peça lisa | Fotografe uma peça estampada combinada com uma lisa do estoque atual. | — |
| 19 | O que perguntar antes de fechar | Personalizar os campos e revisar o texto. | — |
| 20 | O detalhe desta [PEÇA] | Escolha um detalhe diferente do dia 4: gola, manga, fechamento ou barra. Fotografe a peça real. | — |
| 21 | Gostou de uma peça da vitrine? | Personalizar os campos e revisar o texto. | — |
| 22 | Uma combinação para a sua rotina | Monte um look diferente dos dias 8 e 12. Fotografe sobre uma superfície, em cabide ou manequim. | 5 |
| 23 | Três perguntas antes de escolher | Personalizar os campos e revisar o texto. | — |
| 24 | Qual dessas cores é a sua escolha? | Fotografe juntas as variações de cor realmente disponíveis. Não altere as cores da roupa na edição. | — |
| 25 | O que você quer ver em detalhes? | Personalizar os campos e revisar o texto. | — |
| 26 | Antes da foto da vitrine | Registre mãos organizando uma peça ou montando um look. Não mostre pedidos, etiquetas com dados pessoais ou rostos sem autorização. | — |
| 27 | Como receber sua escolha | Personalizar os campos e revisar o texto. | — |
| 28 | Três peças da nossa vitrine | Fotografe três peças diferentes, com posição clara da esquerda para a direita. Todas devem estar disponíveis quando publicar. | 6 |
| 29 | Uma última conferida no pedido | Personalizar os campos e revisar o texto. | — |
| 30 | O que você procura para o próximo mês? | Personalizar os campos e revisar o texto. | — |

## Organização por semana

- Dias 1–7: apresente peças e descubra preferências do público.
- Dias 8–14: mostre combinações, medidas e detalhes.
- Dias 15–21: esclareça preço e ajude na consulta de produtos.
- Dias 22–30: mostre novas combinações e ouça sugestões para a próxima seleção.

## Registro simples de resultado

Depois de cada publicação, anote o número de consultas recebidas sobre a peça e quantas viraram pedidos confirmados. Pergunte pelo atendimento qual post trouxe a consulta, sem supor que toda venda veio dele. Compare períodos iguais. Ao testar uma mudança, mantenha o restante semelhante e mude apenas um elemento, como a chamada final. O kit não garante alcance, consultas ou vendas.
