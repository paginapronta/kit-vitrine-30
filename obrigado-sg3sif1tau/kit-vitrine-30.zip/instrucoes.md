# Kit Vitrine 30 — guia de uso

Trinta artes de feed para uma loja de roupas, acompanhadas de legendas e calendário. Os bônus são seis roteiros de vídeo e seis capas editáveis. Os vídeos não vêm gravados: os roteiros orientam a gravação de suas próprias peças.

## Comece pela sua loja

1. Faça uma cópia dos arquivos editáveis e preserve os originais.
2. Preencha o nome da loja, o perfil e o contato de atendimento onde aparecerem.
3. Escolha as peças que realmente tem disponíveis. Fotografe com boa luz, sem filtros que mudem a cor da roupa.
4. Troque os campos entre colchetes, tanto nas artes quanto nas legendas e roteiros.
5. No PowerPoint, clique no ícone de imagem da área indicada e escolha a foto da sua peça. Confira se a foto aparece e se os detalhes importantes estão visíveis.
6. Salve a cópia. Use Arquivo > Exportar, escolha PNG e exporte os 30 slides de feed. Confira as imagens inteiras antes de publicar.

Os textos e campos são sugestões para adaptar. Se uma peça, forma de entrega ou condição não faz parte da sua operação, substitua o trecho. Para uma loja online, use fotos da seleção ou da preparação de pedidos em vez de sugerir que existe uma loja física.

## Campos que você vai preencher

| Campo | O que colocar |
| --- | --- |
| [NOME DA LOJA] | Nome usado pela sua loja |
| [@SUALOJA] | Seu perfil, com @ |
| [WHATSAPP] | Contato comercial completo com DDD |
| [PEÇA] | Nome curto e específico, como camisa de linho |
| [DETALHE REAL DA PEÇA] | Um detalhe visível e verdadeiro, como botões frontais |
| [TAMANHOS] | Tamanhos disponíveis daquele modelo |
| [COMPLEMENTO 1] e [COMPLEMENTO 2] | Outras peças usadas nas combinações fotografadas |
| [COR 1] e [COR 2] | Cores das peças mostradas |
| [CORES DISPONÍVEIS] | Cores que você pode oferecer naquele momento |
| [COMPOSIÇÃO DA ETIQUETA] | Composição exatamente como consta na etiqueta |
| [OCASIÃO] | Situação para a qual você montou o look |
| [HORÁRIO DE ATENDIMENTO] | Dias e horários reais de resposta |
| [PREÇO] | Preço real da peça, com R$ e centavos |
| [CONDIÇÕES DO PREÇO] | Forma de pagamento e condições necessárias para aquele preço |
| [FORMA DE RECEBIMENTO] | Entrega, envio ou retirada que você realmente oferece |

Use nomes curtos nas artes. Se o título preenchido ficar longo, encurte a frase e deixe os detalhes para a legenda. Ajuste os artigos e as concordâncias conforme o produto: “a camisa”, “o vestido”, “as calças”. Depois da edição, procure pelo caractere `[` para localizar campos esquecidos. A busca ajuda, mas a revisão visual continua necessária.

## Exemplo preenchido

Exemplo fictício, apenas para mostrar a substituição:

- `[NOME DA LOJA]`: Loja Exemplo
- `[PEÇA]`: camisa azul
- `[DETALHE REAL DA PEÇA]`: botões frontais
- `[TAMANHOS]`: P e M

A frase “Hoje a vitrine é da [PEÇA]” vira “Hoje a vitrine é da camisa azul”. Use os dados da sua loja na versão que vai publicar.

## Fotos e identidade

As artes usam creme, carvão e vinho, com fonte Arial. Personalize os textos e as fotos mantendo essa paleta. A troca global de cores não foi testada por interface e não faz parte do fluxo oferecido.

Use fotos suas ou imagens com autorização para esse uso. Uma foto de peça parecida não substitui a foto do produto oferecido. Quando mostrar um conjunto, explique na legenda se algum item não está à venda ou se os preços são separados.

Nas imagens de bastidores, confira se aparecem dados de clientes, etiquetas de envio ou telas de atendimento. Use um enquadramento que mostre apenas a preparação. Pessoas reconhecíveis só devem aparecer com autorização.

## Legendas e calendário

O número de cada arte corresponde ao número em `legendas.md` e ao dia em `calendario.md`. Copie a legenda correspondente e revise seus campos. As hashtags são opcionais: mantenha apenas as que descrevem a publicação. Você pode acrescentar uma hashtag da sua cidade quando fizer sentido.

O calendário começa quando você quiser. Não depende de mês, feriado ou estação. Você também pode espaçar as publicações. Consulte o estoque, os valores e as condições novamente no dia de usar cada arte.

As legendas convidam o público a consultar a loja. Adapte a chamada ao canal em que você realmente atende. Evite oferecer resposta imediata se você não consegue cumprir.

## Roteiros e capas de Reel

Cada roteiro em `roteiros.md` tem cenas, duração, texto na tela e legenda. As capas correspondem aos números de 1 a 6. Grave as peças na vertical e use a capa correspondente na edição do vídeo.

Os roteiros permitem filmar cabides, manequins, peças sobre uma superfície e mãos montando combinações. Não é necessário mostrar o rosto. Música é opcional e não acompanha o kit. Use áudio próprio ou com licença adequada ao uso comercial.

Antes de usar a capa, confira os recortes na prévia do aplicativo. Mantenha o título e a peça principal longe das bordas.

## Confira antes de publicar

- Todos os campos da arte e da legenda receberam dados reais.
- A peça fotografada corresponde à peça oferecida.
- Preço, tamanhos e condições estão atualizados.
- O texto cabe, tem contraste e pode ser lido no celular.
- Nenhuma foto ou texto está cortado de forma indevida.
- O contato leva ao atendimento da loja.

O kit oferece material para organizar a comunicação. Alcance, consultas e vendas dependem de fatores que os arquivos não controlam.

## Compatibilidade e fluxo verificado

Arquivos PPTX para uso no PowerPoint 16.78, no Mac. O teste por interface confirmou:

- Edição dos textos.
- Inserção de foto pelo ícone da área de imagem.
- Exportação PNG dos 30 posts de feed em 1080 × 1350, pelo menu Arquivo > Exportar.

A troca global de cores e o fluxo manual no Keynote não foram testados e não fazem parte da oferta. Canva, Google Slides, PowerPoint no Windows e no celular também não foram testados. O kit não inclui licença do PowerPoint.

Os seis roteiros e as seis capas acompanham o kit como bônus. A exportação das capas por interface não foi testada; a exportação PNG comprovada corresponde aos 30 posts de feed.

## Entrega e suporte

Para compras por Pix, o link do kit é enviado ao e-mail informado na compra em até 24 horas após a confirmação do pagamento.

Para suporte, use o endereço informado na página de compra e no e-mail de entrega. Resposta em até 2 dias úteis.
