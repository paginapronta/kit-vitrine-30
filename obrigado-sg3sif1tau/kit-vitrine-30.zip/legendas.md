# Legendas dos 30 posts

Substitua os campos entre colchetes e confira as informações antes de usar. As hashtags são opcionais. Os números correspondem aos editáveis.

## 01 — Uma peça para conhecer de perto

Hoje a vitrine é da [PEÇA]. Ela tem [DETALHE REAL DA PEÇA] e está disponível nos tamanhos [TAMANHOS]. Quer conferir as medidas? Fale com a gente pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 02 — A mesma peça, outro jeito de usar

Montamos duas combinações com a mesma [PEÇA]: uma com [COMPLEMENTO 1] e outra com [COMPLEMENTO 2]. Qual você usaria primeiro? As peças fotografadas estão na [NOME DA LOJA]. Consulte a disponibilidade pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 03 — O que conferir na sua próxima peça

Vale olhar além da cor: medida, composição e acabamento também fazem parte da escolha. Se quiser ver um detalhe de uma peça da nossa vitrine, peça uma foto pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 04 — Chegue mais perto do acabamento

Na foto, você vê [DETALHE REAL DA PEÇA]. Fizemos esse registro de perto para ajudar na sua escolha. Quer ver a peça inteira? Peça pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 05 — O que você mais usa na semana?

Queremos conhecer o que faz parte do seu guarda-roupa. Você usa mais peças lisas, estampadas ou mistura tudo? Escreva nos comentários. Suas respostas ajudam a orientar nossas próximas seleções.

#LojaDeRoupas #ModaNoDiaADia

## 06 — Duas cores para experimentar juntas

Hoje juntamos [COR 1] e [COR 2] nas peças da foto. Você prefere essa combinação ou usaria cada cor separadamente? Confira tamanhos e disponibilidade pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 07 — Quer ver uma peça com mais detalhes?

Para consultar uma peça, envie a foto ou o nome dela pelo [WHATSAPP]. Informe também o tamanho que você procura. Atendemos em [HORÁRIO DE ATENDIMENTO].

#LojaDeRoupas #ModaNoDiaADia

## 08 — Um look para [OCASIÃO]

Nossa sugestão para [OCASIÃO] reúne [PEÇA] e [COMPLEMENTO 1]. Você usaria assim ou mudaria alguma coisa? Consulte cada peça e os tamanhos disponíveis pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 09 — Como pedir ajuda com o tamanho

A numeração pode variar entre modelos. Para comparar, peça as medidas da peça que você gostou pelo [WHATSAPP]. Use uma roupa sua como referência. A comparação ajuda, mas não garante o caimento.

#LojaDeRoupas #ModaNoDiaADia

## 10 — O tecido visto de perto

Este é um detalhe do tecido da [PEÇA]. A composição informada na etiqueta é [COMPOSIÇÃO DA ETIQUETA]. Quer outra foto ou as medidas? Nosso contato é [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 11 — Qual detalhe chama sua atenção?

Cada pessoa repara em uma coisa primeiro. Conte nos comentários: você olha mais para o corte, para a cor ou para o acabamento? Vamos mostrar esses detalhes nos próximos posts.

#LojaDeRoupas #ModaNoDiaADia

## 12 — Uma base para dois looks

A mesma base aparece em duas propostas: [PEÇA] com [COMPLEMENTO 1] e com [COMPLEMENTO 2]. Qual delas entraria na sua rotina? Consulte as peças disponíveis pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 13 — A etiqueta acompanha a peça

Antes de lavar ou passar, consulte a etiqueta da sua roupa. Se algum símbolo estiver pouco legível, procure a orientação do fabricante. Para conferir a etiqueta de uma peça da nossa loja antes da compra, fale pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 14 — Um pedacinho da [NOME DA LOJA]

Esse é um registro da nossa seleção de hoje. Gostou de alguma peça da foto? Envie a imagem pelo [WHATSAPP] e indique qual chamou sua atenção. Vamos conferir a disponibilidade.

#LojaDeRoupas #ModaNoDiaADia

## 15 — Na vitrine por [PREÇO]

Em destaque: [PEÇA] por [PREÇO]. Condições: [CONDIÇÕES DO PREÇO]. Tamanhos disponíveis na data deste post: [TAMANHOS]. Consulte disponibilidade e custo de entrega pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 16 — A peça de frente e de costas

Aqui você vê a frente e as costas da [PEÇA]. O detalhe que destacamos é [DETALHE REAL DA PEÇA]. Quer conferir as medidas antes de escolher? Peça pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 17 — Qual cor você quer ver por aqui?

Tem alguma cor que você procura e sente falta de encontrar? Escreva nos comentários. A resposta ajuda na nossa pesquisa para futuras seleções, sem compromisso de reposição.

#LojaDeRoupas #ModaNoDiaADia

## 18 — Uma estampa com uma peça lisa

Escolhemos uma peça estampada e uma lisa para montar o look da foto. Qual parte você manteria? Se quiser saber mais sobre [PEÇA], fale com a gente pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 19 — O que perguntar antes de fechar

Antes de confirmar o pedido, confira modelo, tamanho, valor total e forma de receber. Peça também as condições de troca aplicáveis à compra. Nosso canal de atendimento é [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 20 — O detalhe desta [PEÇA]

Hoje o foco está em [DETALHE REAL DA PEÇA]. A foto mostra como esse detalhe aparece na [PEÇA]. Veja a disponibilidade nos tamanhos [TAMANHOS] pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 21 — Gostou de uma peça da vitrine?

Viu uma peça no nosso perfil e quer saber mais? Envie a foto pelo [WHATSAPP] com o tamanho que procura. A gente confere medidas, valor e disponibilidade antes de você decidir.

#LojaDeRoupas #ModaNoDiaADia

## 22 — Uma combinação para a sua rotina

Essa combinação reúne [PEÇA] e [COMPLEMENTO 1]. Em qual momento da sua semana você usaria esse look? Para consultar os modelos da foto, chame pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 23 — Três perguntas antes de escolher

Uma roupa nova pode conversar com o que você já tem. Antes de escolher, pense em quando usaria e quais peças suas combinariam com ela. Se quiser ver um detalhe de algum modelo, estamos no [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 24 — Qual dessas cores é a sua escolha?

Estas são as cores disponíveis da [PEÇA] na data deste post: [CORES DISPONÍVEIS]. A disponibilidade de tamanhos pode variar por cor. Consulte a sua combinação pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 25 — O que você quer ver em detalhes?

Que tipo de foto ajuda mais na sua escolha: peça inteira, tecido de perto ou combinação completa? Responda nos comentários. Vamos usar as sugestões para preparar os próximos conteúdos.

#LojaDeRoupas #ModaNoDiaADia

## 26 — Antes da foto da vitrine

Hoje mostramos um pouco da preparação das fotos na [NOME DA LOJA]. A peça deste registro é [PEÇA]. Quer ver o resultado de perto? Consulte os detalhes pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 27 — Como receber sua escolha

Na [NOME DA LOJA], a forma de receber é [FORMA DE RECEBIMENTO]. Antes de fechar o pedido, consulte o prazo e o custo para o seu caso pelo [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 28 — Três peças da nossa vitrine

Reunimos três peças da seleção atual em uma foto. Qual você quer ver de perto: a primeira, a segunda ou a terceira? Indique nos comentários ou envie a foto pelo [WHATSAPP] para consultar detalhes.

#LojaDeRoupas #ModaNoDiaADia

## 29 — Uma última conferida no pedido

Na hora de confirmar, confira os detalhes do seu pedido com a loja. Se algo estiver diferente do que você escolheu, avise antes de concluir. Para falar com a [NOME DA LOJA], use [WHATSAPP].

#LojaDeRoupas #ModaNoDiaADia

## 30 — O que você procura para o próximo mês?

Estamos ouvindo sugestões para os próximos conteúdos e seleções da [NOME DA LOJA]. Qual peça você procura ou para qual ocasião quer montar um look? Conte nos comentários. As sugestões não são confirmação de encomenda ou reposição.

#LojaDeRoupas #ModaNoDiaADia
