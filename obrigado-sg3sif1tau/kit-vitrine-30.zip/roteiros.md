# Seis roteiros de Reel

Bônus: os vídeos ainda precisam ser gravados e editados. Cada roteiro dura 15 segundos. Você pode filmar as peças e as mãos, sem mostrar o rosto. Grave na vertical, mantenha os textos longe das bordas e confira a prévia no aplicativo. As capas editáveis acompanham os roteiros.

O áudio é opcional. Use áudio próprio ou com licença adequada ao uso comercial. O kit não inclui músicas.

## 01 — Uma peça, dois looks

Foto da capa: Fotografe a peça central com um dos looks completos, deixando espaço acima para o título.

| Tempo | Cena | Texto na tela |
| --- | --- | --- |
| 0–3s | Mostre a peça sozinha no cabide, com a câmera parada. | Uma peça, dois looks |
| 3–7s | Mostre a primeira combinação completa. | Com [COMPLEMENTO 1] |
| 7–11s | Troque apenas o complemento e registre a segunda combinação. | Com [COMPLEMENTO 2] |
| 11–15s | Volte às duas combinações, em cortes curtos. | Qual você usaria? |

**Legenda:** Uma [PEÇA], duas combinações da nossa vitrine. Qual você escolheria: com [COMPLEMENTO 1] ou [COMPLEMENTO 2]? Consulte tamanhos e disponibilidade pelo [WHATSAPP].

#IdeiasDeLooks #LojaDeRoupas

## 02 — Os detalhes da peça

Foto da capa: Use um close da peça real com acabamento nítido.

| Tempo | Cena | Texto na tela |
| --- | --- | --- |
| 0–3s | Enquadre a peça inteira em cabide ou manequim. | De perto: [PEÇA] |
| 3–6s | Aproxime a câmera do primeiro detalhe, sem zoom digital. | Em foco: [DETALHE REAL DA PEÇA] |
| 6–10s | Mostre o tecido em luz uniforme, sem filtro. | Um olhar para a textura |
| 10–15s | Retorne à peça inteira e deixe a imagem parada. | Peça as medidas: [WHATSAPP] |

**Legenda:** Um vídeo para ver a [PEÇA] com mais calma. Composição da etiqueta: [COMPOSIÇÃO DA ETIQUETA]. Para consultar medidas e disponibilidade, fale pelo [WHATSAPP].

#DetalhesDaRoupa #LojaDeRoupas

## 03 — Duas cores, um look

Foto da capa: Fotografe as duas peças juntas, respeitando suas cores reais.

| Tempo | Cena | Texto na tela |
| --- | --- | --- |
| 0–3s | Mostre a primeira peça sobre uma superfície limpa. | Começa com [COR 1] |
| 3–7s | Coloque a segunda peça ao lado da primeira. | Entra [COR 2] |
| 7–11s | Mostre a combinação completa de cima. | A combinação completa |
| 11–15s | Faça um corte para um detalhe das peças juntas. | Você usaria essas cores juntas? |

**Legenda:** Nossa combinação de hoje junta [COR 1] e [COR 2]. Você usaria assim? As peças do vídeo fazem parte da seleção da [NOME DA LOJA]. Consulte a disponibilidade pelo [WHATSAPP].

#CombinacaoDeCores #ModaNoDiaADia

## 04 — Frente, costas e detalhes

Foto da capa: Use a peça inteira de frente, sem cortar mangas ou barra.

| Tempo | Cena | Texto na tela |
| --- | --- | --- |
| 0–4s | Mostre a frente da peça inteira. | De frente |
| 4–8s | Vire o cabide ou manequim para mostrar as costas. | De costas |
| 8–12s | Aproxime de um detalhe real. | Em foco: [DETALHE REAL DA PEÇA] |
| 12–15s | Retorne ao enquadramento inicial. | Dúvidas? [WHATSAPP] |

**Legenda:** A [PEÇA] vista de frente e de costas, com um detalhe em close. Tamanhos disponíveis: [TAMANHOS]. Para saber medidas e valor, fale com a gente pelo [WHATSAPP].

#VitrineDaLoja #LojaDeRoupas

## 05 — A montagem do look

Foto da capa: Registre o look completo montado sobre uma superfície neutra.

| Tempo | Cena | Texto na tela |
| --- | --- | --- |
| 0–3s | Comece com a superfície vazia e coloque a peça central. | Uma ideia para [OCASIÃO] |
| 3–7s | Adicione a segunda peça com as mãos fora do texto. | No look: [PEÇA] + [COMPLEMENTO 1] |
| 7–11s | Ajuste as peças para mostrar a combinação completa. | O look completo |
| 11–15s | Mantenha a câmera parada na composição final. | O que você mudaria? |

**Legenda:** Montamos essa combinação para [OCASIÃO]. Você manteria as peças ou trocaria algum detalhe? Para consultar os modelos do vídeo, envie uma mensagem pelo [WHATSAPP].

#MontandoLook #LojaDeRoupas

## 06 — Três peças da semana

Foto da capa: Reúna as três peças, sem cortar detalhes importantes.

| Tempo | Cena | Texto na tela |
| --- | --- | --- |
| 0–3s | Mostre as três peças juntas. | Qual é a sua escolha? |
| 3–6s | Enquadre apenas a primeira peça. | Opção 1 |
| 6–9s | Enquadre apenas a segunda peça. | Opção 2 |
| 9–12s | Enquadre apenas a terceira peça. | Opção 3 |
| 12–15s | Volte à imagem com as três peças. | Conte: 1, 2 ou 3? |

**Legenda:** Três peças da nossa seleção atual. Qual você quer conhecer melhor: 1, 2 ou 3? Comente ou envie a imagem pelo [WHATSAPP] para consultar medidas, valor e disponibilidade.

#SelecaoDaSemana #LojaDeRoupas
